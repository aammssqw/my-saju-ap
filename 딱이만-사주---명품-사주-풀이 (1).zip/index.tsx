
import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";

const KAKAO_LINK = "https://open.kakao.com/o/smPIizgi";

const App = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [sajuResult, setSajuResult] = useState<any>(null);
  const [formData, setFormData] = useState({
    date: '1995-01-01',
    time: '09:00',
    gender: 'MALE'
  });

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 300);
    return () => clearTimeout(timer);
  }, []);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    setIsLoading(true);
    try {
      const genAI = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const model = 'gemini-3-flash-preview';

      const prompt = `
        사용자 정보: 생년월일(${formData.date}), 시간(${formData.time}), 성별(${formData.gender === 'MALE' ? '남성' : '여성'})
        위 정보를 바탕으로 전통 명리학(사주)을 분석하여 아래 JSON 형식으로만 응답해줘.
        형식: {
          "title": "운명의 한 줄 요약",
          "essence": "사주의 핵심 기운 풀이",
          "wealth": "재물운 상세",
          "love": "애정운 상세",
          "advice": "올해의 비책"
        }
        말투는 아주 품격 있고 신비로운 1% 명리학자 스타일로 해줘.
      `;

      const response = await genAI.models.generateContent({
        model,
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        config: {
          systemInstruction: "당신은 '딱이만'이라는 별칭을 가진 대한민국 최고의 명리학자입니다. 기품 있는 고어와 현대적 감각을 섞어 신비로운 통찰을 제공합니다.",
          responseMimeType: "application/json"
        }
      });

      const resultText = response.text;
      if (!resultText) throw new Error("기운을 읽는 데 실패했습니다.");
      
      setSajuResult(JSON.parse(resultText));
    } catch (error: any) {
      console.error("Saju Error:", error);
      alert("현재 천기의 흐름이 불안정합니다. 잠시 후 다시 시도해 주세요.");
    } finally {
      setIsLoading(false);
    }
  };

  if (!isLoaded) return <div className="bg-[#0a0a0b] min-h-screen"></div>;

  return (
    <div className="max-w-md mx-auto px-6 py-16 min-h-screen flex flex-col">
      <header className="text-center mb-16 animate-fade">
        <h1 className="text-4xl font-serif font-black text-white tracking-widest mb-2">딱이만 사주</h1>
        <div className="w-8 h-[1px] bg-amber-500/40 mx-auto mb-2"></div>
        <p className="text-[9px] text-amber-500 uppercase tracking-[0.5em] font-bold">Elite Destiny Insight</p>
      </header>

      <main className="flex-grow animate-fade" style={{ animationDelay: '0.2s' }}>
        {!sajuResult ? (
          <div className="glass-panel p-8 rounded-3xl premium-shadow">
            <form onSubmit={handleAnalyze} className="space-y-8">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Birth Date</label>
                <input 
                  type="date" 
                  value={formData.date}
                  onChange={e => setFormData({...formData, date: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl text-white outline-none focus:border-amber-500/30 transition-colors"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Birth Time</label>
                  <input 
                    type="time" 
                    value={formData.time}
                    onChange={e => setFormData({...formData, time: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 p-4 rounded-xl text-white outline-none"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Gender</label>
                  <select 
                    value={formData.gender}
                    onChange={e => setFormData({...formData, gender: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 p-4 rounded-xl text-white outline-none appearance-none"
                  >
                    <option value="MALE">남성</option>
                    <option value="FEMALE">여성</option>
                  </select>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-amber-500 hover:bg-amber-400 text-black font-black py-5 rounded-xl text-lg transition-all active:scale-[0.98] shadow-lg shadow-amber-500/20 flex items-center justify-center gap-3 disabled:opacity-50"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-black/20 border-t-black rounded-full animate-spin"></div>
                ) : '나의 운명 확인하기'}
              </button>
            </form>
          </div>
        ) : (
          <div className="space-y-6 animate-fade">
            <button 
              onClick={() => setSajuResult(null)} 
              className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest hover:text-white mb-2"
            >
              ← 다시 입력하기
            </button>
            
            <div className="glass-panel rounded-[2.5rem] overflow-hidden premium-shadow">
              <div className="bg-gradient-to-b from-amber-500 to-amber-600 p-10 text-center">
                <h2 className="text-2xl font-serif font-black text-black leading-tight">{sajuResult.title}</h2>
                <div className="w-6 h-[1px] bg-black/20 mx-auto mt-4"></div>
              </div>
              
              <div className="p-8 space-y-10">
                <section>
                  <h3 className="text-amber-500 text-[9px] font-bold tracking-[0.3em] uppercase mb-4">The Essence</h3>
                  <p className="text-xl font-serif text-white leading-relaxed italic border-l-2 border-amber-500/30 pl-5">"{sajuResult.essence}"</p>
                </section>

                <div className="relative pt-10 border-t border-white/5 min-h-[260px] flex flex-col items-center justify-center text-center">
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-md rounded-2xl z-10 flex flex-col items-center justify-center p-6">
                    <div className="bg-amber-500 text-black text-[8px] font-black px-3 py-1 rounded-full mb-4 tracking-widest uppercase">Premium Only</div>
                    <p className="text-white font-bold text-lg mb-6 leading-snug">
                      재물운, 애정운, 올해의 비책은<br/>
                      <span className="text-amber-500">유료 회원에게만 공개됩니다.</span>
                    </p>
                    <a 
                      href={KAKAO_LINK} 
                      target="_blank" 
                      className="bg-white text-black px-10 py-4 rounded-xl font-black text-sm shadow-xl hover:scale-105 transition-transform"
                    >
                      상담 예약 및 전체 보기 ⚡
                    </a>
                  </div>
                  
                  <div className="opacity-5 blur-sm select-none">
                    <p className="text-xs mb-2">재물운이 매우 왕성하여 큰 이익이 따를 것입니다.</p>
                    <p className="text-xs mb-2">사랑하는 사람과의 관계가 더욱 깊어지는 시기입니다.</p>
                    <p className="text-xs">동쪽으로 가면 길한 기운을 받을 수 있습니다.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="mt-16 py-8 text-center border-t border-white/5">
        <p className="text-[9px] text-zinc-600 tracking-[0.4em] font-bold uppercase">© DDAGIMAN Fortune Lab</p>
      </footer>
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
